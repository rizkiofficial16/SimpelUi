<?php

namespace Rizz\SimpelUi;

use pocketmine\Server;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;

use jojoe77777\FormAPI\{FormAPI, SimpleForm, CustomForm};

class main extends PluginBase implements Listener {
    
    public function onEnable(){
        $this->getLogger()->info("Its enabled UwU");
    }
    
    public function onDisable(){
        $this->getLogger()->info("Its disabled UwU");
    }
    
    public function onCommand(CommandSender $sender, Command $cmd, String $label, Array $args) : bool {
        
        switch($cmd->getName()){
            case "su":
            if($sender instanceof Player){
                $this->mainForm($sender);
             }else{
                  $sender->sendMessage("§cYou don't have permission");
              }
        }
    return true;
    }
    /* MAIN FORM */
    public function mainForm(Player $player){
        $form = new SimpleForm(function(Player $player, int $data = null){
            if($data === null){
                return true;
            }
            switch($data){
                case 0:
                    $player->setHealth(20);
                    $player->sendMessage("§aHeal Your Self");
                break;
                case 1:
                    $player->setFood(20);
                    $player->setSaturation(20);
                    $player->sendMessage("§aFeed Your Self");
                break;
                case 2:
                    $this->flyForm($player);
                break;
            }
        });
        $form->setTitle("Simple Ui");
        $form->setContent("§aPlugin by rizkiofficial16");
        $form->addButton("Heal", 0, "textures/ui/heal");
        $form->addButton("Feed", 0, "textures/ui/feed");
        $form->addButton("Fly", 0, "textures/ui/fly");
        $form->sendToPlayer($player);
        return $form;
    }
    /* FLY FORM */
    public function flyForm(Player $player){
        $form = new SimpleForm(function(Player $player, int $data = null){
            if($data === null){
                $this->mainForm($player);
                return true;
            }
            switch($data){
                case 0:
                    $player->setAllowFlight(true);
                    $player->sendMessage("§aYou can fly");
                break;
                
                case 1:
                    $player->setAllowFlight(false);
                    $player->sendMessage("§aYou can't fly");
                break;
                
                case 2:
                    $this->mainForm($player);
                break;
            }
        });
        $form->setTitle("§2Fly §6U§fI");
        $form->setContent("§aPlugin by rizkiofficial16");
        $form->addButton("§aFly §2Enable");
        $form->addButton("§aFly §cDisable");
        $form->addButton("§cBack", 0, "textures/ui/barrier");
        $form->sendToPlayer($player);
        return $form;
    }    
}